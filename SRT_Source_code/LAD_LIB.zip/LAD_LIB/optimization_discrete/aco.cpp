#include "aco.h"

#include <iomanip>

/****************************************************************************
* Copyright (C), 2021-2032 �廪��ѧ���캽��ѧԺ����ѧ�����ʵ����
* ����: ���� zhong-zh19@mails.tsinghua.edu.cn
*            539977562@qq.com
* �ļ���: aco.cpp
* ���ݼ�������Ⱥ�㷨ʵ���ļ�����max-min��������ֲ��Ż����ɽ��mtsp����
*
* �ļ���ʷ��
* �汾��     ����         ����       ˵��
* 01        2021-09-26    ����      �����ļ�
****************************************************************************/

int ACO::up_ = 0;
int ACO::candidate_length_ = 20;

ACO::ACO(double(*ObjFun)(const std::vector<int>& X, void* f_data), 
	double (*HeurFun)(const std::vector<int>& X_0, const int X_1, void* f_data),
	double (*Localsearch)(std::vector<int>& X, void* f_data),
	int up, int m, int iter, int candidate_n , double alpha, double beta, double rho, double delta)
{
	//��ʼ������
	ObjFun_ = ObjFun;
	HeurFun_ = HeurFun;
	Localsearch_ = Localsearch;
	up_ = up;
	m_ant_num_ = m;
	max_iterations_ = iter;
	alpha_ = alpha;
	beta_ = beta;
	evaporation_ = rho;
	delta_ = delta;
	candidate_n_ = candidate_n;

	ants_.resize(m_ant_num_);
	for(int ant_id = 0; ant_id<ants_.size(); ant_id++)
	{
		ants_[ant_id].para_[0] = candidate_n_;
	}

	Tau_.resize(up_ + 2);
	for(int i = 0; i< Tau_.size(); i++)
	{
		Tau_[i].resize(up_ + 1);
		for(int j =0; j < Tau_[i].size();j++)
		{
			Tau_[i][j] = 1.0;
		}
	}
	best_result_now_.Optimization_index_ = 1.0e10;
	best_result_all_.Optimization_index_ = 1.0e10;

}

void ACO::Run()
{
	Reset();                        //�����Ϸ��û����

	for (; iter_ < max_iterations_; iter_++,iter_after_reinit_++)
	{
#pragma omp parallel for schedule(dynamic)
		for (int ant_id = 0; ant_id < ants_.size(); ant_id++)
		{
			ants_[ant_id].run(Tau_,alpha_,beta_,HeurFun_);
			ants_[ant_id].Optimization_index_ = ObjFun_(ants_[ant_id].x_, ants_[ant_id].para_);
			double local_para[1000],local_min = ants_[ant_id].Optimization_index_;

			int counter = 0, counter_max = 20; 
			while(true)
			{
				local_para[0] = { ants_[ant_id].Optimization_index_ };
				ants_[ant_id].Optimization_index_ = Localsearch_(ants_[ant_id].x_, local_para);
				if( fabs(local_min - ants_[ant_id].Optimization_index_) < 1.e-8)
				{
					break;
				}
				local_min = ants_[ant_id].Optimization_index_;
				counter++;
			}
			
		}

		Result_update();                //�������
		
		Output_info(std::cout);      //�����Ϣ

		Deposit_update();               //��Ϣ�ظ���

		Reset();                        //һ�ֽ����������Ϸ��û����
	}

}

void ACO::Result_update()
{
	for (int ant_id = 0; ant_id < ants_.size(); ant_id++)
	{
		if (best_result_now_ > ants_[ant_id])
		{
			best_result_now_ = ants_[ant_id];
		}
	}

	if (best_result_all_ > best_result_now_)
	{
		best_result_all_ = best_result_now_;
	}

	best_result_each_iter_.push_back(best_result_all_.Optimization_index_);
}

void ACO::Deposit_update()
{
	//����Tau_max,Tau_min
	max_tau_ = 1.0 / (1.0 - evaporation_) / best_result_all_.Optimization_index_;
	min_tau_ = max_tau_ / (2.0 * up_);  //�˴�ʹ�õ���max-min�㷨�У���Դ���TSP������������



	//ѡ�������Ϣ�صĸ��� now or all�� ʹ�õ����¶�̬��������
	Ant update_temp = best_result_now_ ;
	if (iter_after_reinit_ <= 25)
	{
		update_temp = best_result_now_; //��������
	}
	else if (25 < iter_after_reinit_ && iter_after_reinit_ <= 75)
	{
		update_temp = (75 - iter_after_reinit_) % 5 == 0 ? best_result_all_ : best_result_now_; //�����һ��ȫ�ָ���
	}
	else if (75 < iter_after_reinit_ && iter_after_reinit_ <= 125)
	{
		update_temp = (125 - iter_after_reinit_) % 3 == 0 ? best_result_all_ : best_result_now_; //3����һ��ȫ�ָ���
	}
	else if (125 < iter_after_reinit_ && iter_after_reinit_ <= 250)
	{
		update_temp = (250 - iter_after_reinit_) % 2 == 0 ? best_result_all_ : best_result_now_; //3����һ��ȫ�ָ���
	}
	else
	{
		update_temp = best_result_all_;
	}

	//������50�����û�и���ʱ��ʹ��ȫ����
	if(iter_after_reinit_ > 50 &&  iter_ > 250 && fabs( best_result_all_.Optimization_index_- best_result_each_iter_[iter_ -25]) < 1.0e-8)
	{
		update_temp = best_result_all_;
	}

	//������Ϣ��
	for(int i=0; i< Tau_.size();i++)
	{
		for(int j= 0; j<Tau_[i].size();j++)
		{
			Tau_[i][j] *= evaporation_;
			if (Tau_[i][j] < min_tau_) Tau_[i][j] = min_tau_;
		}
	}
	//��������·�����
	for(int i = 1;i< update_temp.x_.size(); i++)
	{
		Tau_[update_temp.x_[i-1]][update_temp.x_[i]] += 1. / update_temp.Optimization_index_;
		if (Tau_[update_temp.x_[i - 1]][update_temp.x_[i]] > max_tau_) Tau_[update_temp.x_[i - 1]][update_temp.x_[i]] = max_tau_;
	}

	Tau_[ACO::up_ + 1][update_temp.x_[0]] += 1. / update_temp.Optimization_index_;
	if (Tau_[ACO::up_ + 1][update_temp.x_[0]] > max_tau_) 
		Tau_[ACO::up_ + 1][update_temp.x_[0]] = max_tau_;


	//PTS����
	double delta_temp = delta_;
	//80����û����ߣ����³�ʼ��
	if (iter_ > 300 && iter_after_reinit_ > 100 && fabs(best_result_all_.Optimization_index_ - best_result_each_iter_[iter_ - 50]) < 1.0e-8)
	{
		delta_temp = 1.0;
		iter_after_reinit_ = 0;
	}
	if (iter_ == 0)
	{
		delta_temp = 1.0;
		iter_after_reinit_ = 0;
	}
	for (int i = 0; i < Tau_.size(); i++)
	{
		for (int j = 0; j < Tau_[i].size(); j++)
		{
			Tau_[i][j] = Tau_[i][j] + delta_temp * (max_tau_ - Tau_[i][j]);
		}
	}

}

void ACO::Output_info(std::ostream& fout1)
{
	fout1 <<"iter:" << iter_ << "  reinit_iter:"<< iter_after_reinit_ << "  iteration best:" << 1. * best_result_now_.Optimization_index_ <<"   global best:"<<1. * best_result_all_.Optimization_index_
	       <<std::endl;

	//double tf[123],dtf[123];
	//for(int i = 0; i<best_result_all_.x_.size(); i++)
	//{
	//	tf[i] = best_result_all_.para_[2 * i + 1];
	//}
	//for(int i = 1; i< 123;i++)
	//{
	//	dtf[i] = tf[i] - tf[i - 1];
	//}
	//dtf[0] = 0.0;

	//for (int i = 0; i < 123; i++)
	//{
	//	fout1 << std::setprecision(5)<<tf[i]<<" ";
	//}
	//fout1 << std::endl;
	//for (int i = 0; i < 123; i++)
	//{
	//	fout1 << std::setprecision(5) << dtf[i] << " ";
	//}
	//fout1 << std::endl;

	//int counter = 0, missions = 0; 
	//for(int i = 0; i < 123; i++)
	//{
	//	counter++;
	//	if( fabs(dtf[i] - 30)<1e-8 )
	//	{
	//		fout1 << counter <<" ";
	//		counter = 0;
	//		missions++;
	//	}
	//}

	//if(counter != 0)
	//{
	//	fout1 << counter << " ";
	//	missions++;
	//}

	//fout1 << "�ܹ�����" << missions;
	//fout1 << std::endl;
}

void ACO::Reset()
{
	//�������ϷŻس�ʼ�㣬���ԭ��·��;���ѡ���ʼ��,ÿ�����Ž�����
	for (int ant_id = 0; ant_id < ants_.size(); ant_id++)
	{
		ants_[ant_id].x_.clear();
		ants_[ant_id].initialize_random(up_,Tau_,alpha_);
	}

	best_result_now_.Optimization_index_ = 1.0e10;
}

Ant::Ant()
{
	x_.clear();
	Optimization_index_ = 0.0;
}

std::vector<std::pair<int, double>> Ant::candidate(void* f_data, double (*HeurFun)(const std::vector<int>& X_0, const int X_1, void* f_data), std::vector<
	                                                   Problem_para_candidate>& para_next)
{


	std::vector<std::pair<int, double>> candidate_next;
	for (int next = 0; next <= ACO::up_; next++)
	{
		double para_temp[1000];
		memcpy(para_temp, f_data, 1000 * sizeof(double));

		double heur_temp = HeurFun(x_, next, para_temp);
		if (heur_temp > 0.0) {
			std::pair<int, double> temp(next, heur_temp);
			candidate_next.push_back(temp);
			Problem_para_candidate problem_temp; problem_temp.x = next; memcpy(problem_temp.para, para_temp, 1000 * sizeof(double));
			para_next.push_back(problem_temp);
		}
	}

	int candidate_length = ACO::candidate_length_; 

	//����������������
	std::sort(candidate_next.begin(), candidate_next.end(), [](std::pair<int, double> A, std::pair<int, double> B) {return A.second > B.second; });

	if (candidate_next.size() > candidate_length)
	{
		candidate_next.erase(candidate_next.begin()+ candidate_length, candidate_next.end());
	}
	return candidate_next;
}

int Ant::step(std::vector<std::pair<int, double>> candidate, double* para, const std::vector<std::vector<double>>& Tau, double  alpha, double beta)
{
	double p_total = 0.0;
	std::vector<double> p_each(candidate.size());
	for (int candidate_id = 0; candidate_id < candidate.size(); candidate_id++)
	{
		p_each[candidate_id] = pow(Tau[x_.back()][candidate[candidate_id].first], alpha)* pow(candidate[candidate_id].second, beta);
		p_total += p_each[candidate_id];
		if (candidate_id > 0) p_each[candidate_id] += p_each[candidate_id - 1];
	}

	for (int candidate_id = 0; candidate_id < candidate.size(); candidate_id++)
	{
		p_each[candidate_id] /= p_total;
	}

	//��ʱp_each�ڲ�Ϊ���ʣ��Ұ�����ӵķ�ʽ���루���һ�����Ϊ1.0����ʹ�����̶ķ�ʽ����

	double random = realRand(0.0, 1.0);

	for (int candidate_id = 0; candidate_id < candidate.size(); candidate_id++)
	{
		if (random < p_each[candidate_id])
		{
			//������ս��
			return candidate[candidate_id].first;
		}
	}
}

void Ant::initialize_random(int up, const std::vector<std::vector<double>>& Tau, double alpha)
{
	double p_total = 0.0;
	std::vector<double> p_each(ACO::up_ + 1);
	for (int candidate_id = 0; candidate_id < p_each.size(); candidate_id++)
	{
		p_each[candidate_id] = pow(Tau[ACO::up_ + 1][candidate_id], alpha) * 1.0;
		p_total += p_each[candidate_id];
		if (candidate_id > 0) p_each[candidate_id] += p_each[candidate_id - 1];
	}

	for (int candidate_id = 0; candidate_id < p_each.size(); candidate_id++)
	{
		p_each[candidate_id] /= p_total;
	}

	//��ʱp_each�ڲ�Ϊ���ʣ��Ұ�����ӵķ�ʽ���루���һ�����Ϊ1.0����ʹ�����̶ķ�ʽ����

	double random = realRand(0.0, 1.0);

	for (int candidate_id = 0; candidate_id < p_each.size(); candidate_id++)
	{
		if (random < p_each[candidate_id])
		{
			//������ս��
			x_.push_back(candidate_id);
			break;
		}
	}
	

	////ԭ�з���
	//int next = intRand(0, up);
	//next = 23;// TODO:�����ʼ����
	//x_.push_back(next);

}

void Ant::run(const std::vector<std::vector<double>> &Tau, double  alpha, double beta, 
	double (*HeurFun)(const std::vector<int>& X_0, const int X_1, void* f_data)
 )
{
	while (true)
	{
		std::vector<Problem_para_candidate> temp;
		temp.reserve(ACO::up_ + 1);
		std::vector<std::pair<int, double>> candidate_result = candidate(para_, HeurFun, temp);
		if (candidate_result.size() == 0) break;

		double data[1]={0.0}; //TODO:��һ������Ĳ���
		int next = step(candidate_result, data, Tau, alpha, beta);
		x_.push_back(next);
		for(int i = 0 ; i< temp.size(); i++)
		{
			if (temp[i].x == next)
			{
				memcpy(para_, temp[i].para, 1000 * sizeof(double));
				break;
			}
		}
	}
}

void Ant::operator=(const Ant& result)
{
	Optimization_index_ = result.Optimization_index_;
	x_ = result.x_;
	memcpy(para_, result.para_, 1000 * sizeof(double));
}

bool Ant::operator<(const Ant& result)
{
	if (Optimization_index_ < result.Optimization_index_)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Ant::operator>(const Ant& result)
{
	if (Optimization_index_ > result.Optimization_index_)
	{
		return true;
	}
	else
	{
		return false;
	}
}